# TODO: luck cycles
