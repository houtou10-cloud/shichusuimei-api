# TODO: pillar calculation
